const MidiWriter = require('./build');

const track = new MidiWriter.Track();

track.addEvent(new MidiWriter.CopyrightEvent({text: "Garrett Grimm"}));
track.removeEventsByName('CopyrightEvent');
track.addEvent(new MidiWriter.NoteEvent({pitch: ["C4", "D4", "E4"], sequential: true}));

const track2 = new MidiWriter.Track();

track2.addEvent(new MidiWriter.NoteEvent({pitch: ["E4", "F4", "G4"], sequential: true}));

track.mergeTrack(track2);

const write = new MidiWriter.Writer([track]);

console.log((new TextDecoder()).decode(write.buildFile()));
