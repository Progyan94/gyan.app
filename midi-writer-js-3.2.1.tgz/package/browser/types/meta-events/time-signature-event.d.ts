import { MetaEvent } from './meta-event';
/**
 * Object representation of a time signature meta event.
 * @return {TimeSignatureEvent}
 */
declare class TimeSignatureEvent implements MetaEvent {
    data: number[];
    delta: number;
    name: string;
    type: 0x58;
    constructor(numerator: any, denominator: any, midiclockspertick: any, notespermidiclock: any);
}
export { TimeSignatureEvent };
