import { MetaEvent } from './meta-event';
/**
 * Object representation of a key signature meta event.
 * @return {KeySignatureEvent}
 */
declare class KeySignatureEvent implements MetaEvent {
    data: number[];
    delta: number;
    name: string;
    type: 0x59;
    constructor(sf: any, mi: any);
}
export { KeySignatureEvent };
