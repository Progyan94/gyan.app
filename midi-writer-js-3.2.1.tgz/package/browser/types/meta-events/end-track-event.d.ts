import { MetaEvent } from './meta-event';
/**
 * Object representation of a end track meta event.
 * @param {object} fields {delta: integer}
 * @return {EndTrackEvent}
 */
declare class EndTrackEvent implements MetaEvent {
    data: number[];
    delta: number;
    name: string;
    type: [0x2F, 0x00];
    constructor(fields?: {
        delta: number;
    });
}
export { EndTrackEvent };
