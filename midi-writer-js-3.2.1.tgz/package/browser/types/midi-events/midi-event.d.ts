import { AbstractEvent } from '../abstract-event';
interface MidiEvent extends AbstractEvent {
    channel: number;
    status: number;
    buildData?: Function;
}
export { MidiEvent };
