import { Chunk } from './chunk';
/**
 * Object representation of a header chunk section of a MIDI file.
 * @param {number} numberOfTracks - Number of tracks
 * @return {Header}
 */
declare class Header implements Chunk {
    data: number[];
    type: number[];
    size: number[];
    constructor(numberOfTracks: number, ticksPerBeat?: number);
}
export { Header };
