/**
 * MIDI file format constants.
 * @return {Constants}
 */
declare const Constants: {
    VERSION: string;
    HEADER_CHUNK_TYPE: number[];
    HEADER_CHUNK_LENGTH: number[];
    HEADER_CHUNK_FORMAT0: number[];
    HEADER_CHUNK_FORMAT1: number[];
    HEADER_CHUNK_DIVISION: number[];
    TRACK_CHUNK_TYPE: number[];
    META_EVENT_ID: number;
    META_SMTPE_OFFSET: number;
};
export { Constants };
